create definer = playground@`%` view 제조업체별제품수3 as
select `playground`.`productTest`.`company` AS `업체`, count(`playground`.`productTest`.`pdNum`) AS `제품수`
from `playground`.`productTest`
group by `playground`.`productTest`.`company`;

