create definer = playground@`%` view 제조업체별제품수 as
select `playground`.`productTest`.`company`      AS `company`,
       count(`playground`.`productTest`.`pdNum`) AS `count(pdNum)`
from `playground`.`productTest`
group by `playground`.`productTest`.`company`;

