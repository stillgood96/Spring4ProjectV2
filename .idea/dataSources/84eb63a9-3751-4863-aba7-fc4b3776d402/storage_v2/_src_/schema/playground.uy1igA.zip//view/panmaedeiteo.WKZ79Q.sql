create definer = playground@`%` view 판매데이터 as
select `ot`.`csid`      AS `csid`,
       `ot`.`pdNum`     AS `pdNum`,
       `ot`.`ordNum`    AS `ordNum`,
       `ot`.`quantity`  AS `quantity`,
       `ot`.`adr`       AS `adr`,
       `ot`.`orderdate` AS `orderdate`,
       `pt`.`pdName`    AS `pdName`,
       `pt`.`qunatity`  AS `qunatity`,
       `pt`.`price`     AS `price`,
       `pt`.`company`   AS `company`,
       `ct`.`csname`    AS `csname`,
       `ct`.`age`       AS `age`,
       `ct`.`grd`       AS `grd`,
       `ct`.`job`       AS `job`,
       `ct`.`point`     AS `point`
from ((`playground`.`orderTest` `ot` join `playground`.`productTest` `pt` on (`ot`.`pdNum` = `pt`.`pdNum`))
         join `playground`.`customerTest` `ct` on (`ot`.`csid` = `ct`.`csid`));

